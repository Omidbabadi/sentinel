import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sentinel/core/res/style/colors.dart';
import 'package:sentinel/core/services/router.dart';

import 'core/common/application/riverpod/current_theme_controller.dart';
import 'core/res/style/theme_tokens.dart';

class MainApp extends ConsumerWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = ThemeData(
      scaffoldBackgroundColor: SentinelThemeTokens.lightBackgroundColor,
      colorScheme: ColorScheme.fromSeed(seedColor: Pallet.lightTritaryT10),
      appBarTheme: const AppBarTheme(
        backgroundColor: SentinelThemeTokens.lightBackgroundColor,
        elevation: 0,
      ),
    );
    final themeMode = ref.watch(currentThemeProvider);

    return MaterialApp.router(
      themeMode: themeMode,
      darkTheme: theme.copyWith(
        scaffoldBackgroundColor: SentinelThemeTokens.darkBackgroundColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: SentinelThemeTokens.darkBackgroundColor,
          elevation: 0,
        ),
      ),
      title: "Sentinel",
      theme: theme,
      debugShowCheckedModeBanner: false,
      routerConfig: router,
    );
  }
}
