import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:sentinel/core/utils/core_utils.dart';
import 'package:sentinel/src/hosts/presention/views/hosts_view.dart';
import 'package:xterm2/xterm.dart';

import '../../../../core/common/application/riverpod/active_host_tab_controller.dart';
import '../../../../core/common/entities/host.dart';
import '../../../../core/res/style/colors.dart';
import '../../domain/usecase/connect.dart';
import '../app/adapter/ssh_adapter.dart';

class TerminalsView extends ConsumerStatefulWidget {
  const TerminalsView({super.key, required this.host});
  final Host host;
  static const path = '/hosts/terminal';

  @override
  ConsumerState<TerminalsView> createState() => _TerminalViewState();
}

class _TerminalViewState extends ConsumerState<TerminalsView> {
  // Track which host tab is currently selected
  late Host _activeHost;

  @override
  void initState() {
    super.initState();
    _activeHost = widget.host;
    CoreUtils.postFrameCallback(() {
      ref.read(activeHostTabControllerProvider.notifier).addTab(_activeHost);
      _initConnect(_activeHost);
    });
  }

  @override
  void didUpdateWidget(covariant TerminalsView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.host.id != widget.host.id) {
      _activeHost = widget.host;
      CoreUtils.postFrameCallback(() {
        ref.read(activeHostTabControllerProvider.notifier).addTab(_activeHost);
        _initConnect(_activeHost);
      });
    }
  }

  void _initConnect(Host host) {
    final hostId = host.id;
    if (hostId == null) return;

    final current = ref.read(sshAdapterProvider.notifier).stateFor(hostId);
    if (current is! SshConnected && current is! SshConnecting) {
      _connect(host);
    }
  }

  void _connect([Host? targetHost]) {
    final host = targetHost ?? _activeHost;
    final hostId = host.id;
    if (hostId == null) return;

    ref.read(sshAdapterProvider.notifier).connect(ConnectParams(host: host));
  }

  void _closeTab(int hostId) {
    ref.read(sshAdapterProvider.notifier).disconnect(hostId);
    ref.read(activeHostTabControllerProvider.notifier).removeTab(hostId);

    final remaining = ref.watch(activeHostTabControllerProvider);
    if (remaining.isEmpty) {
      if (context.canPop()) {
        context.pop();
      } else {
        context.go(HostsView.path);
      }
      return;
    }

    if (_activeHost.id == hostId) {
      setState(() {
        _activeHost = remaining.last.host;
      });
      _initConnect(_activeHost);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sshStateMap = ref.watch(sshAdapterProvider);
    final tabs = ref.watch(activeHostTabControllerProvider);
    final activeHostId = _activeHost.id;

    // Ensure the active host is always visible in tabs even before the postFrameCallback runs
    final hasActiveInTabs = tabs.any((tab) => tab.id == activeHostId);
    final allTabs = [
      ...tabs,
      if (!hasActiveInTabs && activeHostId != null)
        (id: activeHostId, host: _activeHost),
    ];

    final sshState = activeHostId != null
        ? (sshStateMap[activeHostId] ?? const SshInitial())
        : const SshInitial();

    return SafeArea(
      child: Column(
        children: [
          Container(
            height: 48,
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: Theme.of(context).dividerColor.withValues(alpha: 0.2),
                ),
              ),
            ),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, size: 20),
                  tooltip: 'Back to hosts',
                  onPressed: () {
                    if (context.canPop()) {
                      context.pop();
                    } else {
                      context.go(HostsView.path);
                    }
                  },
                ),
                Expanded(
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 6,
                    ),
                    itemCount: allTabs.length,
                    separatorBuilder: (_, _) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final tab = allTabs[index];
                      final isSelected = tab.id == activeHostId;
                      final tabState = sshStateMap[tab.id];

                      return Material(
                        color: isSelected
                            ? Theme.of(context).colorScheme.primaryContainer
                            : Theme.of(context)
                                  .colorScheme
                                  .surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(8),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(8),
                          onTap: () {
                            if (_activeHost.id != tab.id) {
                              setState(() {
                                _activeHost = tab.host;
                              });
                              _initConnect(tab.host);
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // Status dot indicator
                                Icon(
                                  Icons.terminal_rounded,
                                  size: 16,
                                  color: tabState is SshConnected
                                      ? Colors.greenAccent
                                      : tabState is SshConnecting
                                      ? Colors.amberAccent
                                      : tabState is SshError
                                      ? Pallet.criticalRose
                                      : Theme.of(context)
                                            .colorScheme
                                            .onSurfaceVariant,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  tab.host.hostname,
                                  style: Theme.of(context).textTheme.labelLarge
                                      ?.copyWith(
                                        fontWeight: isSelected
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                ),
                                const SizedBox(width: 8),
                                // Close button on tab
                                InkWell(
                                  borderRadius: BorderRadius.circular(12),
                                  onTap: () => _closeTab(tab.id),
                                  child: const Padding(
                                    padding: EdgeInsets.all(2),
                                    child: Icon(Icons.close_rounded, size: 16),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.add, size: 20),
                  tooltip: 'Open new host session',
                  onPressed: () {
                    if (context.canPop()) {
                      context.pop();
                    } else {
                      context.go(HostsView.path);
                    }
                  },
                ),
              ],
            ),
          ),

          // 2. Active Terminal / Connection State View
          Expanded(
            child: switch (sshState) {
              SshInitial() || SshConnecting() => Column(
                children: [
                  const LinearProgressIndicator(),
                  Expanded(
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const CircularProgressIndicator(),
                          const SizedBox(height: 16),
                          Text(
                            'Connecting to ${_activeHost.hostname}...',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SshConnected(:final terminal) => TerminalView(
                terminal,
                key: ValueKey(
                  activeHostId,
                ), // Important so Flutter updates the view on tab switch
                autofocus: true,
              ),
              SshError(:final message) => Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.error_outline_rounded,
                        color: Pallet.criticalRose,
                        size: 56,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Connection Failed',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                      const SizedBox(height: 24),
                      FilledButton.icon(
                        onPressed: () => _connect(_activeHost),
                        icon: const Icon(Icons.refresh),
                        label: const Text('Try Again'),
                      ),
                    ],
                  ),
                ),
              ),
              SshDisconnected(:final message) => Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.power_off_rounded,
                        size: 56,
                        color: Pallet.lightSubtleStroke,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Disconnected',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        message ?? 'Session was terminated.',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      const SizedBox(height: 24),
                      FilledButton.icon(
                        onPressed: () => _connect(_activeHost),
                        icon: const Icon(Icons.refresh),
                        label: const Text('Reconnect'),
                      ),
                    ],
                  ),
                ),
              ),
            },
          ),
        ],
      ),
    );
  }
}
