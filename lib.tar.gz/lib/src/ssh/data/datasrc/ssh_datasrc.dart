import 'dart:convert';

import 'package:dartssh2/dartssh2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:sentinel/core/security/credential_store.dart';
import 'package:sentinel/src/hosts/data/model/host_model.dart';
import 'package:sentinel/src/hosts/data/model/linux_os_model.dart';

import '../../../../core/enums/ssh_auth_type.dart';
import '../../../../core/errors/exceptions.dart';
import '../../../../core/handler/host_key_prompts_handler.dart';

abstract class SshDatasrc {
  Future<SSHClient> connect({required HostModel host});
}

class SshDatasrcImpl implements SshDatasrc {
  const SshDatasrcImpl(this._credentialStore, this._hostKeyPromptHandler);
  final CredentialStore _credentialStore;
  final PromptHandler _hostKeyPromptHandler;

  static const _connectionTimeout = Duration(seconds: 15);
  static const _authenticationTimeout = Duration(seconds: 15);

  @override
  Future<SSHClient> connect({required HostModel host}) async {
    final hostId = host.id;

    if (hostId == null) {
      throw const SshException(
        message: 'Cannot connect to a Host without a database ID.',
      );
    }

    final secret = await _credentialStore.readSecret(hostId);

    if (secret == null || secret.isEmpty) {
      throw const SshException(
        message: 'No SSH credentials found for this Host.',
      );
    }

    final socket = await SSHSocket.connect(
      host.ip,
      host.port,
    ).timeout(_connectionTimeout);

    SSHClient? client;

    try {
      final identities = <SSHKeyPair>[];

      if (host.authType == SshAuthType.privateKey) {
        final passphrase = await _credentialStore.readPassphrase(hostId);

        identities.addAll(
          SSHKeyPair.fromPem(
            secret,
            passphrase == null || passphrase.isEmpty ? null : passphrase,
          ),
        );
      }

      client = SSHClient(
        socket,
        username: host.username,
        onPasswordRequest: host.authType == SshAuthType.password
            ? () => secret
            : null,
        onUserInfoRequest: host.authType == SshAuthType.password
            ? (request) => List.filled(request.prompts.length, secret)
            : null,
        identities: host.authType == SshAuthType.privateKey ? identities : null,
        onVerifyHostKey: (keyType, fingerprint) async {
          final verifyHostKey = await _verifyHostKey(
            fingerprint: fingerprint,
            host: host,
            keyType: keyType,
          );

          return verifyHostKey;
        },
        handshakeTimeout: _connectionTimeout,
        authTimeout: _authenticationTimeout,
        keepAliveInterval: const Duration(seconds: 15),
      );

      await client.authenticated.timeout(_authenticationTimeout);
      final result = await client.run('cat /etc/os-release');
      final string = utf8.decode(result);
      final os = LinuxOsModel.fromOsRelease(string);
      print(os.osVersion);
      return client;
    } on SshException {
      rethrow;
    } catch (e, s) {
      debugPrint(e.toString());
      debugPrintStack(stackTrace: s);
      if (client != null) {
        client.close();
      } else {
        socket.close();
      }
      if (e is SSHAuthFailError) {
        throw const SshException(
          message:
              'Authentication failed. Please verify your credentials '
              'and authentication method.',
        );
      }
      if (e is SSHHostkeyError) {
        throw const SshException(
          message: 'Host key verification failed or was rejected.',
        );
      }
      throw SshException(
        message: 'Error occurred during SSH connection: ${e.toString()}',
      );
    }
  }

  Future<bool> _verifyHostKey({
    required HostModel host,
    required String keyType,
    required Uint8List fingerprint,
  }) async {
    final hostId = host.id;
    if (hostId == null) return false;

    final presentedFingerprint = utf8.decode(fingerprint, allowMalformed: true);
    final savedFingerprint = await _credentialStore.readHostFingerprint(hostId);
    if (savedFingerprint == presentedFingerprint) {
      return true;
    }

    final isFirstConnection = savedFingerprint == null;
    final accepted = await _hostKeyPromptHandler.verifyHostKeyPromptsHandler(
      host: host,
      keyType: keyType,
      fingerprint: fingerprint,
      presentedFingerprint: presentedFingerprint,
      isFirstConnection: isFirstConnection,
    );

    if (accepted) {
      await _credentialStore.saveHostFingerprint(
        hostId: hostId,
        fingerprint: presentedFingerprint,
      );
    }

    return accepted;
  }
}
