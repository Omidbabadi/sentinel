import 'package:flutter/material.dart';

class AddHostFloutingActionButton extends StatelessWidget {
  const new({super.key, required this.onPressed});
  final void Function() onPressed;

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(onPressed: onPressed, child: Icon(Icons.add));
  }
}
