import 'package:flutter/material.dart';

import '../../../../core/res/style/theme_tokens.dart';
import '../../../../core/widgets/glass_orb_painter.dart';

class SentinelDashboard extends StatefulWidget {
  final bool isDark;
  final VoidCallback onToggleTheme;
  final bool includeFakeStatusBar;

  const SentinelDashboard({
    super.key,
    required this.isDark,
    required this.onToggleTheme,
    this.includeFakeStatusBar = false,
  });

  @override
  State<SentinelDashboard> createState() => _SentinelDashboardState();
}

class _SentinelDashboardState extends State<SentinelDashboard> {
  int _selectedNavIndex = 0;

  @override
  Widget build(BuildContext context) {
    final tokens = SentinelThemeTokens(widget.isDark);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [tokens.bgTop, tokens.bgBottom],
        ),
      ),
      child: Stack(
        children: [
          // Ambient subtle glow behind the 3D sphere and cards
          Positioned(
            top: 90,
            right: -35,
            child: IgnorePointer(
              child: CustomPaint(
                size: const Size(210, 210),
                painter: GlassOrbPainter(isDark: widget.isDark),
              ),
            ),
          ),

          // Ambient teal/blue subtle radial glow behind Network Traffic card
          if (widget.isDark)
            Positioned(
              top: 300,
              left: 70,
              child: IgnorePointer(
                child: Container(
                  width: 180,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF32789A).withOpacity(0.18),
                        blurRadius: 65,
                        spreadRadius: 25,
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // Main Scrollable Content
          Positioned.fill(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.only(
                top: widget.includeFakeStatusBar ? 48 : 20,
                left: 16,
                right: 16,
                bottom: 104,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [],
              ),
            ),
          ),

          // Bottom Floating Glassmorphic Dock + Center Terminal Orb
          Positioned(
            left: 16,
            right: 16,
            bottom: 16,
            child: _buildBottomNavigation(tokens),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar(SentinelThemeTokens tokens) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Brand Logo + Name
        GestureDetector(
          onTap: widget.onToggleTheme,
          behavior: HitTestBehavior.opaque,
          child: Row(
            children: [
              SizedBox(
                width: 24,
                height: 24,
                child: CustomPaint(
                  painter: SentinelCubeLogoPainter(isDark: widget.isDark),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Sentinel',
                style: TextStyle(
                  color: tokens.textPrimary,
                  fontSize: 16.5,
                  fontWeight: FontWeight.w500,
                  letterSpacing: -0.2,
                ),
              ),
            ],
          ),
        ),
        // Right Action Icons (Bell + User Avatar)
        Row(
          children: [
            IconButton(
              onPressed: widget.onToggleTheme,
              tooltip: 'Switch Light/Dark Theme',
              visualDensity: VisualDensity.compact,
              icon: Icon(
                Icons.notifications_none_rounded,
                color: tokens.textPrimary.withOpacity(0.75),
                size: 21,
              ),
            ),
            const SizedBox(width: 4),
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: tokens.cardBorder, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: ClipOval(
                child: CustomPaint(painter: UserPortraitAvatarPainter()),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBottomSplitCards(SentinelThemeTokens tokens) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Left Card: Quick Actions
          Expanded(
            child: GlassCard(
              tokens: tokens,
              padding: const EdgeInsets.all(12),
              borderRadius: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Quick Actions',
                    style: TextStyle(
                      color: tokens.textPrimary,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 10),
                  _buildQuickActionButton(
                    tokens: tokens,
                    icon: Icons.add_rounded,
                    label: 'Add Host',
                  ),
                  const SizedBox(height: 7),
                  _buildQuickActionButton(
                    tokens: tokens,
                    icon: Icons.terminal_rounded,
                    label: 'Open Terminal',
                  ),
                  const SizedBox(height: 7),
                  _buildQuickActionButton(
                    tokens: tokens,
                    icon: Icons.people_outline_rounded,
                    label: 'Create Group',
                  ),
                  const SizedBox(height: 7),
                  _buildQuickActionButton(
                    tokens: tokens,
                    icon: Icons.insights_rounded,
                    label: 'Monitor',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          // Right Card: System Overview
          Expanded(
            child: GlassCard(
              tokens: tokens,
              padding: const EdgeInsets.all(12),
              borderRadius: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'System Overview',
                    style: TextStyle(
                      color: tokens.textPrimary,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Donut Ring + Legend
                  Row(
                    children: [
                      SizedBox(
                        width: 62,
                        height: 62,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CustomPaint(
                              size: const Size(62, 62),
                              painter: SystemDonutChartPainter(
                                isDark: widget.isDark,
                                green: tokens.greenAccent,
                                red: tokens.redAccent,
                                yellow: tokens.yellowAccent,
                              ),
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '6',
                                  style: TextStyle(
                                    color: tokens.textPrimary,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    height: 1.0,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Total Hosts',
                                  style: TextStyle(
                                    color: tokens.textSecondary,
                                    fontSize: 7.5,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          children: [
                            _buildLegendRow(
                              tokens,
                              tokens.greenAccent,
                              'Online',
                              '5',
                            ),
                            const SizedBox(height: 6),
                            _buildLegendRow(
                              tokens,
                              tokens.redAccent,
                              'Offline',
                              '1',
                            ),
                            const SizedBox(height: 6),
                            _buildLegendRow(
                              tokens,
                              tokens.yellowAccent,
                              'Staging',
                              '0',
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  const SizedBox(height: 10),
                  // CPU Mini Metric Row
                  _buildMetricSparklineRow(
                    tokens: tokens,
                    title: 'CPU',
                    value: '14%',
                    seed: 1,
                    lineColor: tokens.greenAccent,
                  ),
                  const SizedBox(height: 6),
                  // Memory & Disk Mini Metric Row
                  _buildMetricSparklineRow(
                    tokens: tokens,
                    title: 'Memory  42%',
                    value: 'Disk 23%',
                    seed: 2,
                    lineColor: tokens.yellowAccent,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton({
    required SentinelThemeTokens tokens,
    required IconData icon,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6.5),
      decoration: BoxDecoration(
        color: tokens.innerPillSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tokens.innerPillBorder, width: 0.8),
      ),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: widget.isDark
                  ? Colors.white.withOpacity(0.06)
                  : Colors.black.withOpacity(0.04),
            ),
            child: Icon(
              icon,
              size: 12.5,
              color: tokens.textPrimary.withOpacity(0.8),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: tokens.textPrimary.withOpacity(0.9),
                fontSize: 10.5,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegendRow(
    SentinelThemeTokens tokens,
    Color color,
    String label,
    String count,
  ) {
    return Row(
      children: [
        Container(
          width: 5.5,
          height: 5.5,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color,
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.5), blurRadius: 4),
            ],
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            label,
            style: TextStyle(color: tokens.textSecondary, fontSize: 10),
          ),
        ),
        Text(
          count,
          style: TextStyle(
            color: tokens.textPrimary,
            fontSize: 10,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildMetricSparklineRow({
    required SentinelThemeTokens tokens,
    required String title,
    required String value,
    required int seed,
    required Color lineColor,
  }) {
    return Row(
      children: [
        Expanded(
          flex: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: tokens.textSecondary,
                  fontSize: 9,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                value,
                style: TextStyle(
                  color: tokens.textPrimary.withOpacity(0.85),
                  fontSize: 9.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          flex: 6,
          child: SizedBox(
            height: 20,
            child: CustomPaint(
              painter: MiniSparklinePainter(
                seed: seed,
                primaryColor: lineColor,
                secondaryColor: tokens.blueAccent,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomNavigation(SentinelThemeTokens tokens) {
    return SizedBox(
      height: 66,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.bottomCenter,
        children: [
          // Frosted Pill Bar
          ClipRRect(
            borderRadius: BorderRadius.circular(32),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                height: 56,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: widget.isDark
                      ? const Color(0xFF1A1E24).withOpacity(0.82)
                      : Colors.white.withOpacity(0.75),
                  borderRadius: BorderRadius.circular(32),
                  border: Border.all(color: tokens.cardBorder, width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(
                        widget.isDark ? 0.4 : 0.08,
                      ),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNavItem(
                      index: 0,
                      icon: Icons.home_filled,
                      label: 'Home',
                      tokens: tokens,
                    ),
                    _buildNavItem(
                      index: 1,
                      icon: Icons.dns_outlined,
                      label: 'Hosts',
                      tokens: tokens,
                    ),
                    const SizedBox(width: 54), // Space for center orb
                    _buildNavItem(
                      index: 3,
                      icon: Icons.people_outline_rounded,
                      label: 'Groups',
                      tokens: tokens,
                    ),
                    _buildNavItem(
                      index: 4,
                      icon: Icons.more_horiz_rounded,
                      label: 'More',
                      tokens: tokens,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Raised Center Glowing Terminal Button
          Positioned(
            top: 0,
            child: GestureDetector(
              onTap: () => setState(() => _selectedNavIndex = 2),
              child: Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    center: const Alignment(-0.3, -0.4),
                    radius: 0.9,
                    colors: widget.isDark
                        ? [
                            const Color(0xFF3A4352),
                            const Color(0xFF1F242D),
                            const Color(0xFF15181F),
                          ]
                        : [
                            const Color(0xFFFFFFFF),
                            const Color(0xFFE0DDD5),
                            const Color(0xFFCCC8BE),
                          ],
                  ),
                  border: Border.all(
                    color: widget.isDark
                        ? const Color(0xFF7096B8).withOpacity(0.55)
                        : Colors.white.withOpacity(0.9),
                    width: 1.4,
                  ),
                  boxShadow: [
                    if (widget.isDark)
                      BoxShadow(
                        color: const Color(0xFF4788C7).withOpacity(0.28),
                        blurRadius: 16,
                        spreadRadius: 1,
                      ),
                    BoxShadow(
                      color: Colors.black.withOpacity(
                        widget.isDark ? 0.5 : 0.15,
                      ),
                      blurRadius: 12,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    '>_',
                    style: TextStyle(
                      color: tokens.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.5,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required IconData icon,
    required String label,
    required SentinelThemeTokens tokens,
  }) {
    final isSelected = _selectedNavIndex == index;
    final color = isSelected ? tokens.textPrimary : tokens.textSecondary;

    return GestureDetector(
      onTap: () => setState(() => _selectedNavIndex = index),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 52,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 19, color: color),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 9.5,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
