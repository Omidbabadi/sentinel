import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:sentinel/core/common/application/riverpod/current_theme_controller.dart';

import 'package:sentinel/src/dashboard/presention/widgets/floating_action_button.dart';
import 'package:sentinel/src/hosts/presention/views/edit_host_view.dart';
import 'package:sentinel/src/hosts/presention/widgets/dock.dart';

class Dashboard extends ConsumerWidget {
  const Dashboard({
    super.key,
    required this.state,
    required this.child,
    this.includeFakeStatusBar = false,
  });
  final GoRouterState state;
  final Widget child;
  final bool includeFakeStatusBar;
  void _toggleTheme(WidgetRef ref) {
    final theme = ref.read(currentThemeProvider);
    ref.read(currentThemeProvider.notifier).toggleTheme(theme);
  }

  // bool _showFab(ScreenTab tab) => tab == ScreenTab.hosts;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = ref.watch(currentThemeProvider);

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () => _toggleTheme(ref),
            icon: Icon(switch (theme) {
              ThemeMode.dark => Icons.dark_mode_outlined,
              ThemeMode.light => Icons.light_mode_outlined,
              ThemeMode.system => Icons.brightness_auto_outlined,
            }),
            tooltip: 'Toggle Theme',
          ),
        ],
        title: const Text('Sentinel'),
      ),
      body: Padding(padding: const EdgeInsets.all(8.0), child: child),
      floatingActionButton: AddHostFloutingActionButton(
        onPressed: () => context.push(EditHostView.path),
      ),
      bottomNavigationBar: Dock(),
    );
  }
}
