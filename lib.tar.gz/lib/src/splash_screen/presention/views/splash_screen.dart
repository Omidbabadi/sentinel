import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:sentinel/core/widgets/app_logo.dart';
import 'package:sentinel/src/hosts/presention/app/adapter/hosts_adapter.dart';
import 'package:sentinel/src/hosts/presention/views/hosts_view.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const new({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await ref.read(hostsAdapterProvider.notifier).getHostFromLocalBase();
    });
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(hostsAdapterProvider, (previous, next) {
      if (next is HostsLoaded) {
        context.go(HostsView.path);
      }
      if (next is HostsError) {
        debugPrint(next.message);
      }
    });
    return Scaffold(body: const Center(child: AppLogo()));
  }
}
