part of 'hosts_adapter.dart';

sealed class HostsState {
  const HostsState();
}

final class HostsInitial extends HostsState {}

final class HostsLoading extends HostsState {}

final class HostsLoaded extends HostsState {
  const HostsLoaded(this.hosts);

  final List<Host> hosts;
}

final class HostsError extends HostsState {
  const HostsError(this.message);

  final String message;
}
