import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:sentinel/core/common/entities/host.dart';
import 'package:sentinel/core/services/injection_container.dart';
import 'package:sentinel/src/hosts/domain/usecases/add_host.dart';
import 'package:sentinel/src/hosts/domain/usecases/delete_host.dart';
import 'package:sentinel/src/hosts/domain/usecases/get_hosts.dart';
import 'package:sentinel/src/hosts/domain/usecases/update_host.dart';
part 'hosts_adapter.g.dart';
part 'hosts_state.dart';

@Riverpod(keepAlive: true)
class HostsAdapter extends _$HostsAdapter {
  @override
  HostsState build() {
    _getHostFromLocalBase = sl<GetHosts>();
    _addHost = sl<AddHost>();
    _updateHost = sl<UpdateHost>();
    _deleteHost = sl<DeleteHost>();
    return HostsInitial();
  }

  late final GetHosts _getHostFromLocalBase;
  late final AddHost _addHost;
  late final UpdateHost _updateHost;
  late final DeleteHost _deleteHost;
  Future<void> getHostFromLocalBase() async {
    state = HostsLoading();
    final result = await _getHostFromLocalBase.call();
    result.fold(
      (l) => state = HostsError(l.message),
      (r) => state = HostsLoaded(r),
    );
  }

  Future<void> addHost({
    required Host host,
    required String secret,
    required String? passphrase,
  }) async {
    state = HostsLoading();
    final result = await _addHost.call(
      AddHostParams(host: host, secret: secret, passphrase: passphrase),
    );
    result.fold((l) => state = HostsError(l.message), (r) async {
      await getHostFromLocalBase();
    });
  }

  Future<void> updateHost({
    required Host host,
    String? secret,
    String? passphrase,
  }) async {
    state = HostsLoading();
    final result = await _updateHost.call(
      UpdateHostParams(host: host, secret: secret, passphrase: passphrase),
    );
    result.fold((l) => state = HostsError(l.message), (r) async {
      await getHostFromLocalBase();
    });
  }

  Future<void> deleteHost(int id) async {
    final result = await _deleteHost.call(id);
    result.fold((l) => state = HostsError(l.message), (r) async {
      await getHostFromLocalBase();
    });
  }
}
