import 'package:flutter/material.dart';

import '../../../../core/utils/core_utils.dart';
import 'section_card.dart';

class BuildConnectionSection extends StatelessWidget {
  const new({
    super.key,
    required this.ipController,
    required this.portController,
  });
  final TextEditingController ipController;
  final TextEditingController portController;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Connection Details',
      icon: Icons.network_check_rounded,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 2,
              child: TextFormField(
                controller: ipController,
                textInputAction: TextInputAction.next,
                keyboardType: TextInputType.url,
                decoration: CoreUtils.inputDecoration(
                  context: context,
                  label: 'IP Address / Domain',
                  hint: '192.168.1.100 or ssh.example.com',
                  prefixIcon: Icons.dns_outlined,
                ),
                validator: (val) => CoreUtils.requiredValidator(
                  val,
                  'Host address is required',
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextFormField(
                controller: portController,
                textInputAction: TextInputAction.next,
                keyboardType: TextInputType.number,
                decoration: CoreUtils.inputDecoration(
                  context: context,
                  label: 'Port',
                  hint: '22',
                  prefixIcon: Icons.numbers_rounded,
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) return 'Required';
                  final p = int.tryParse(val.trim());
                  return (p == null || p < 1 || p > 65535) ? 'Invalid' : null;
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}
