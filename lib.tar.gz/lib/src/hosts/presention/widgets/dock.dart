import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:sentinel/core/common/application/riverpod/active_screen_controller.dart';
import 'package:sentinel/core/res/style/colors.dart';
import 'package:sentinel/core/utils/core_utils.dart';
import 'package:sentinel/src/hosts/presention/views/connected_hosts.dart';
import 'package:sentinel/src/hosts/presention/views/hosts_view.dart';

class Dock extends ConsumerWidget {
  const new({super.key});
  static const List<String> _widgetOptions = [
    HostsView.path,
    ConnectedHosts.path,
    '/settings',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedIndex = ref.watch(activeScreenControllerProvider);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(blurRadius: 20, color: Colors.black.withOpacity(.1)),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 8),
          child: GNav(
            rippleColor: Colors.grey[300]!,
            hoverColor: Colors.grey[100]!,
            gap: 8,
            activeColor: Colors.black,
            iconSize: 24,
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            duration: Duration(milliseconds: 400),
            tabBackgroundColor: Pallet.lightSurfaceLayer2,

            color: Colors.black,
            tabs: [
              GButton(
                backgroundColor: CoreUtils.adabtiveColor(
                  context,
                  lightModeColour: Pallet.lightTritaryT90,
                  darkModeColur: Pallet.lightTritaryT50,
                ),
                icon: Icons.dns_rounded,
                text: 'Hosts',
              ),
              GButton(
                backgroundColor: Pallet.meshCyan.withAlpha(50),
                icon: Icons.private_connectivity,
                text: 'Connections',
              ),
              GButton(icon: Icons.settings, text: 'Settings'),
            ],
            selectedIndex: selectedIndex,
            onTabChange: (index) {
              ref.read(activeScreenControllerProvider.notifier).setTab(index);
              context.go(_widgetOptions[index]);
            },
          ),
        ),
      ),
    );
  }
}
