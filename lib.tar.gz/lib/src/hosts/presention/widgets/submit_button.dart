import 'package:flutter/material.dart';

import '../../../../core/res/style/colors.dart';
import '../../../../core/res/style/text.dart';

class SubmitButton extends StatelessWidget {
  const new({
    super.key,
    required this.isEditing,
    required this.isSubmitting,
    required this.saveHost,
  });
  final bool isSubmitting;
  final bool isEditing;
  final void Function() saveHost;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: FilledButton(
        style: FilledButton.styleFrom(
          backgroundColor: Pallet.operationalEmerald,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: isSubmitting ? null : saveHost,
        child: isSubmitting
            ? const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2.5,
                ),
              )
            : Text(
                isEditing ? 'Update Host' : 'Save Host',
                style: TextStyles.buttonTextHeadingSemiBold.copyWith(
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
      ),
    );
  }
}
