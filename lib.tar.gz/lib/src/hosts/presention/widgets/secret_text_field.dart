import 'package:flutter/material.dart';

import '../../../../core/utils/core_utils.dart';

class SecretTextField extends StatefulWidget {
  const SecretTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.hint,
    required this.prefixIcon,
    this.helperText,
    this.validator,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData prefixIcon;
  final String? helperText;
  final FormFieldValidator<String>? validator;

  @override
  State<SecretTextField> createState() => SecretTextFieldState();
}

class SecretTextFieldState extends State<SecretTextField> {
  bool _obscured = true;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      obscureText: _obscured,
      validator: widget.validator,
      decoration: CoreUtils.inputDecoration(
        context: context,
        label: widget.label,
        hint: widget.hint,
        prefixIcon: widget.prefixIcon,
        helperText: widget.helperText,
        suffixIcon: IconButton(
          icon: Icon(
            _obscured
                ? Icons.visibility_outlined
                : Icons.visibility_off_outlined,
            size: 20,
          ),
          onPressed: () => setState(() => _obscured = !_obscured),
        ),
      ),
    );
  }
}
