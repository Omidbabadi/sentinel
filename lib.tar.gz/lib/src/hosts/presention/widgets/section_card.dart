import 'package:flutter/widgets.dart';

import '../../../../core/res/style/colors.dart';
import '../../../../core/res/style/text.dart';
import '../../../../core/utils/core_utils.dart';

class SectionCard extends StatelessWidget {
  const new({
    super.key,
    required this.children,
    required this.icon,
    required this.title,
  });

  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final cardBg = CoreUtils.adabtiveColor(
      context,
      lightModeColour: Pallet.lightSurfaceLayer1,
      darkModeColur: Pallet.darkSurfaceLayer1,
    );
    final borderColor = CoreUtils.adabtiveColor(
      context,
      lightModeColour: Pallet.lightSubtleStroke,
      darkModeColur: Pallet.darkSubtleStroke,
    );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: Pallet.operationalEmerald),
              const SizedBox(width: 8),
              Text(title, style: TextStyles.headingSemiBold1),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }
}
