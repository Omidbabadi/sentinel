import 'package:flutter/material.dart';

import '../../../../core/enums/ssh_auth_type.dart';
import '../../../../core/res/style/text.dart';
import '../../../../core/utils/core_utils.dart';
import 'secret_text_field.dart';
import 'section_card.dart';

class BuildAuthSection extends StatelessWidget {
  const BuildAuthSection({
    super.key,
    required this.secretController,
    required this.selectedAuthType,
    required this.usernameController,
    required this.isEditing,
    required this.onSelectionChanged,
    required this.passphraseController,
  });
  final TextEditingController usernameController;
  final SshAuthType selectedAuthType;
  final TextEditingController secretController;
  final void Function(Set<SshAuthType>)? onSelectionChanged;
  final bool isEditing;
  final TextEditingController passphraseController;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Authentication',
      icon: Icons.shield_outlined,
      children: [
        TextFormField(
          controller: usernameController,
          textInputAction: TextInputAction.next,
          decoration: CoreUtils.inputDecoration(
            context: context,
            label: 'SSH Username',
            hint: 'root',
            prefixIcon: Icons.person_outline_rounded,
          ),
          validator: (val) =>
              CoreUtils.requiredValidator(val, 'Username is required'),
        ),
        const SizedBox(height: 16),
        const Text(
          'Authentication Method',
          style: TextStyles.paragraphSubTextRegular1,
        ),
        const SizedBox(height: 8),
        SegmentedButton<SshAuthType>(
          segments: const [
            ButtonSegment(
              value: SshAuthType.password,
              label: Text('Password'),
              icon: Icon(Icons.password_rounded),
            ),
            ButtonSegment(
              value: SshAuthType.privateKey,
              label: Text('Private Key'),
              icon: Icon(Icons.key_rounded),
            ),
          ],
          selected: {selectedAuthType},
          onSelectionChanged: (selection) {
            onSelectionChanged!(selection);
          },
        ),
        const SizedBox(height: 16),
        if (selectedAuthType == SshAuthType.password)
          SecretTextField(
            controller: secretController,
            label: 'Password',
            hint: 'Enter SSH password',
            prefixIcon: Icons.lock_outline_rounded,
            helperText: isEditing
                ? 'Leave empty to keep existing password'
                : null,
            validator: (val) => isEditing
                ? CoreUtils.requiredValidator(val, 'Password is required')
                : null,
          )
        else ...[
          TextFormField(
            controller: secretController,
            minLines: 4,
            maxLines: 8,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
            decoration: CoreUtils.inputDecoration(
              context: context,
              label: 'Private Key (PEM / OpenSSH)',
              hint: '-----BEGIN OPENSSH PRIVATE KEY-----\n...',
              prefixIcon: Icons.code_rounded,
              helperText: isEditing
                  ? 'Leave empty to keep existing private key'
                  : null,
            ),
            validator: (val) => isEditing
                ? CoreUtils.requiredValidator(val, 'Private key is required')
                : null,
          ),
          const SizedBox(height: 12),
          SecretTextField(
            controller: passphraseController,
            label: 'Key Passphrase (Optional)',
            hint: 'Passphrase for encrypted key',
            prefixIcon: Icons.lock_clock_outlined,
          ),
        ],
      ],
    );
  }
}
