import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:sentinel/core/common/entities/host.dart';
import 'package:sentinel/core/res/style/colors.dart';
import 'package:sentinel/core/res/style/text.dart';
import 'package:sentinel/core/utils/core_utils.dart';
import 'package:sentinel/src/hosts/presention/app/adapter/hosts_adapter.dart';
import 'package:sentinel/src/hosts/presention/views/edit_host_view.dart';
import 'package:sentinel/src/ssh/presention/view/terminal_view.dart';

class HostTile extends ConsumerWidget {
  const new({super.key, required this.host});
  final Host host;

  Future<void> _deleteHost(BuildContext context, WidgetRef ref) async {
    final hostId = host.id;
    if (hostId == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete Host'),
        content: Text(
          'Are you sure you want to delete "${host.hostname}"? This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Pallet.criticalRose),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      await ref.read(hostsAdapterProvider.notifier).deleteHost(hostId);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Pallet.operationalEmerald,
            content: Text('Host deleted successfully'),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.only(left: 16, right: 8, top: 8, bottom: 8),
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: CoreUtils.adabtiveColor(
          context,
          lightModeColour: Pallet.lightSurfaceLayer1,
          darkModeColur: Pallet.darkSurfaceLayer1,
        ),
        border: Border.all(color: Pallet.lightSubtleStroke, width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () {
                context.push(TerminalsView.path, extra: host);
              },
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Pallet.operationalEmerald.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(
                      Icons.terminal,
                      color: Pallet.operationalEmerald,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          host.hostname,
                          style: TextStyles.headingMedium4,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          '${host.username}@${host.ip}:${host.port}',
                          style: TextStyles.paragraphSubTextRegular2.copyWith(
                            fontSize: 11,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded),
            onSelected: (value) {
              if (value == 'edit') {
                context.push(EditHostView.path, extra: host);
              } else if (value == 'delete') {
                _deleteHost(context, ref);
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit_outlined, size: 18),
                    SizedBox(width: 8),
                    Text('Edit'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(
                      Icons.delete_outline,
                      color: Pallet.criticalRose,
                      size: 18,
                    ),
                    SizedBox(width: 8),
                    Text(
                      'Delete',
                      style: TextStyle(color: Pallet.criticalRose),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
