import 'package:flutter/material.dart';

import '../../../../core/utils/core_utils.dart';
import 'section_card.dart';

class GeneralSection extends StatelessWidget {
  const new({
    super.key,
    required this.groupNameController,
    required this.hostnameController,
  });
  final TextEditingController hostnameController;
  final TextEditingController groupNameController;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'General Information',
      icon: Icons.info_outline_rounded,
      children: [
        TextFormField(
          controller: hostnameController,
          textInputAction: TextInputAction.next,
          decoration: CoreUtils.inputDecoration(
            context: context,
            label: 'Display Name / Hostname',
            hint: 'e.g. Production Web Server',
            prefixIcon: Icons.label_outline_rounded,
          ),
          validator: (val) =>
              CoreUtils.requiredValidator(val, 'Hostname is required'),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: groupNameController,
          textInputAction: TextInputAction.next,
          decoration: CoreUtils.inputDecoration(
            context: context,
            label: 'Group / Category (Optional)',
            hint: 'e.g. Web Servers, Database, Home Lab',
            prefixIcon: Icons.folder_outlined,
          ),
        ),
      ],
    );
  }
}
