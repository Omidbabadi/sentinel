import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sentinel/src/hosts/presention/widgets/host_tile.dart';

import '../../../../core/common/application/riverpod/active_host_tab_controller.dart';
import '../../../../core/res/style/colors.dart';
import '../../../../core/res/style/text.dart';

class ConnectedHosts extends ConsumerWidget {
  const new({super.key});
  static const path = '/connetions';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final connections = ref.watch(activeHostTabControllerProvider);

    if (connections.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.cable_outlined, size: 48, color: Pallet.meshCyan),
            SizedBox(height: 12),
            Text(
              'No active connections',
              style: TextStyles.paragraphSubTextRegular1,
            ),
            SizedBox(height: 4),
            Text(
              'Open a terminal from the Hosts tab to start a session.',
              style: TextStyles.paragraphSubTextRegular2,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: connections.length,
      itemBuilder: (context, index) {
        final host = connections[index].host;
        return HostTile(host: host);
      },
    );
  }
}
