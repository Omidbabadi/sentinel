import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:sentinel/core/common/entities/host.dart';
import 'package:sentinel/core/enums/ssh_auth_type.dart';
import 'package:sentinel/core/handler/host_key_prompts_handler.dart';
import 'package:sentinel/core/res/style/colors.dart';
import 'package:sentinel/core/res/style/text.dart';
import 'package:sentinel/core/utils/core_utils.dart';
import 'package:sentinel/src/hosts/data/model/host_model.dart';
import 'package:sentinel/src/hosts/presention/app/adapter/hosts_adapter.dart';
import 'package:sentinel/src/hosts/presention/widgets/auth_section.dart';
import 'package:sentinel/src/hosts/presention/widgets/connection_section.dart';
import 'package:sentinel/src/hosts/presention/widgets/general_section.dart';
import 'package:sentinel/src/hosts/presention/widgets/submit_button.dart';

class EditHostView extends ConsumerStatefulWidget {
  const EditHostView({super.key, this.host});

  static const path = '/hosts/edit';

  final Host? host;

  bool get isEditing => host != null;

  @override
  ConsumerState<EditHostView> createState() => _EditHostViewState();
}

class _EditHostViewState extends ConsumerState<EditHostView> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _hostnameController;
  late final TextEditingController _ipController;
  late final TextEditingController _portController;
  late final TextEditingController _usernameController;
  late final TextEditingController _groupNameController;
  late final TextEditingController _secretController;
  late final TextEditingController _passphraseController;

  late final ValueNotifier<SshAuthType> _selectedAuthType;
  final ValueNotifier<bool> _isSubmitting = ValueNotifier(false);

  List<ChangeNotifier> get _disposables => [
    _hostnameController,
    _ipController,
    _portController,
    _usernameController,
    _groupNameController,
    _secretController,
    _passphraseController,
    _selectedAuthType,
    _isSubmitting,
  ];

  @override
  void initState() {
    super.initState();
    final initial = widget.host;

    _hostnameController = TextEditingController(text: initial?.hostname ?? '');
    _ipController = TextEditingController(text: initial?.ip ?? '');
    _portController = TextEditingController(
      text: (initial?.port ?? 22).toString(),
    );
    _usernameController = TextEditingController(
      text: initial?.username ?? 'root',
    );
    _groupNameController = TextEditingController(
      text: initial?.groupName ?? '',
    );
    _secretController = TextEditingController();
    _passphraseController = TextEditingController();

    _selectedAuthType = ValueNotifier(
      initial?.authType ?? SshAuthType.password,
    );
  }

  @override
  void dispose() {
    for (final disposable in _disposables) {
      disposable.dispose();
    }
    super.dispose();
  }

  Future<void> _saveHost() async {
    if (!_formKey.currentState!.validate()) return;

    _isSubmitting.value = true;

    try {
      final now = DateTime.now();
      final existing = widget.host;
      final secret = CoreUtils.nullIfEmpty(_secretController.text);
      final passphrase = CoreUtils.nullIfEmpty(_passphraseController.text);

      final hostModel = HostModel(
        id: existing?.id,
        hostname: _hostnameController.text.trim(),
        ip: _ipController.text.trim(),
        port: int.tryParse(_portController.text.trim()) ?? 22,
        username: _usernameController.text.trim(),
        authType: _selectedAuthType.value,
        groupName: CoreUtils.nullIfEmpty(_groupNameController.text),
        createdAt: existing?.createdAt ?? now,
        updatedAt: now,
      );

      final notifier = ref.read(hostsAdapterProvider.notifier);

      if (widget.isEditing) {
        await notifier.updateHost(
          host: hostModel,
          secret: secret,
          passphrase: passphrase,
        );
      } else {
        await notifier.addHost(
          host: hostModel,
          secret: secret ?? '',
          passphrase: passphrase,
        );
      }

      if (mounted) {
        CoreUtils.showSnackBar(
          widget.isEditing
              ? 'Host updated successfully'
              : 'Host added successfully',
        );
        context.pop(true);
      }
    } catch (e) {
      CoreUtils.showSnackBar('Failed to save host: $e', isError: true);
    } finally {
      if (mounted) _isSubmitting.value = false;
    }
  }

  Future<void> _confirmDelete() async {
    final host = widget.host;
    if (host?.id == null) return;

    final confirmed = await PromptsHandlerImpl().confirmDeletion(host: host!);

    if (confirmed != true || !mounted) return;

    _isSubmitting.value = true;
    try {
      await ref.read(hostsAdapterProvider.notifier).deleteHost(host.id!);
      if (mounted) {
        CoreUtils.showSnackBar('Host deleted successfully');
        context.pop(true);
      }
    } catch (e) {
      CoreUtils.showSnackBar('Failed to delete host: $e', isError: true);
    } finally {
      if (mounted) _isSubmitting.value = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = CoreUtils.adabtiveColor(
      context,
      lightModeColour: Pallet.lightCanvasBase,
      darkModeColur: Pallet.darkCanvasBase,
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        title: Text(
          widget.isEditing ? 'Edit Host' : 'Add Host',
          style: TextStyles.headingMedium3,
        ),
        centerTitle: true,
        actions: [
          if (widget.isEditing)
            ValueListenableBuilder<bool>(
              valueListenable: _isSubmitting,
              builder: (_, isSubmitting, _) => IconButton(
                icon: const Icon(
                  Icons.delete_outline,
                  color: Pallet.criticalRose,
                ),
                tooltip: 'Delete Host',
                onPressed: isSubmitting ? null : _confirmDelete,
              ),
            ),
        ],
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            children: [
              GeneralSection(
                groupNameController: _groupNameController,
                hostnameController: _hostnameController,
              ),
              const SizedBox(height: 16),
              BuildConnectionSection(
                ipController: _ipController,
                portController: _portController,
              ),
              const SizedBox(height: 16),
              ValueListenableBuilder<SshAuthType>(
                valueListenable: _selectedAuthType,
                builder: (_, authType, _) => BuildAuthSection(
                  isEditing: widget.isEditing,
                  onSelectionChanged: (selection) {
                    _selectedAuthType.value = selection.first;
                  },
                  passphraseController: _passphraseController,
                  secretController: _secretController,
                  selectedAuthType: authType,
                  usernameController: _usernameController,
                ),
              ),
              const SizedBox(height: 24),
              ValueListenableBuilder<bool>(
                valueListenable: _isSubmitting,
                builder: (_, isSubmitting, _) => SubmitButton(
                  isEditing: widget.isEditing,
                  isSubmitting: isSubmitting,
                  saveHost: _saveHost,
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
