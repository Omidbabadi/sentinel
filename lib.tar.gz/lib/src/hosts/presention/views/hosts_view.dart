import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:sentinel/core/res/style/colors.dart';
import 'package:sentinel/core/res/style/text.dart';
import 'package:sentinel/src/hosts/presention/app/adapter/hosts_adapter.dart';
import 'package:sentinel/src/hosts/presention/views/edit_host_view.dart';
import 'package:sentinel/src/hosts/presention/widgets/host_tile.dart';

class HostsView extends ConsumerStatefulWidget {
  const HostsView({super.key});
  static const path = '/hosts';

  @override
  ConsumerState<HostsView> createState() => _HostsViewState();
}

class _HostsViewState extends ConsumerState<HostsView> {
  @override
  Widget build(BuildContext context) {
    final state = ref.watch(hostsAdapterProvider);

    return Padding(
      padding: const EdgeInsets.all(16),
      child: switch (state) {
        HostsInitial() => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.storage_outlined,
                size: 48,
                color: Pallet.meshCyan,
              ),
              const SizedBox(height: 12),
              const Text(
                'Load hosts from database',
                style: TextStyles.paragraphSubTextRegular1,
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                icon: const Icon(Icons.refresh),
                onPressed: () {
                  ref
                      .read(hostsAdapterProvider.notifier)
                      .getHostFromLocalBase();
                },
                label: const Text('Load Hosts'),
              ),
            ],
          ),
        ),
        HostsLoading() => const Center(child: CircularProgressIndicator()),
        HostsError(:final message) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline,
                size: 48,
                color: Pallet.criticalRose,
              ),
              const SizedBox(height: 12),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  ref
                      .read(hostsAdapterProvider.notifier)
                      .getHostFromLocalBase();
                },
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
        HostsLoaded(:final hosts) =>
          hosts.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.computer_outlined,
                        size: 56,
                        color: Pallet.operationalEmerald,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'No SSH hosts configured yet',
                        style: TextStyles.headingSemiBold1,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Add your first server to manage SSH sessions and monitor metrics.',
                        textAlign: TextAlign.center,
                        style: TextStyles.paragraphSubTextRegular2.copyWith(
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 20),
                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: Pallet.operationalEmerald,
                        ),
                        onPressed: () {
                          context.push(EditHostView.path);
                        },
                        icon: const Icon(Icons.add),
                        label: const Text('Add Host'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: hosts.length,
                  itemBuilder: (context, index) {
                    final host = hosts[index];

                    return HostTile(host: host);
                  },
                ),
      },
    );
  }
}
