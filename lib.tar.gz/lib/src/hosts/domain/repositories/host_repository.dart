import 'package:sentinel/core/common/entities/host.dart';
import 'package:sentinel/core/utils/typedefs.dart';

abstract class HostRepository {
  const HostRepository();

  ResultFuture<List<Host>> getHosts();
  ResultFuture<int> addHost({
    required Host host,
    required String secret,
    String? passphrase,
  });

  ResultFuture<void> update({
    required Host host,
    String? secret,
    String? passphrase,
  });

  ResultFuture<void> delete(int hostId);
}
