import 'package:flutter/foundation.dart';
import 'package:sentinel/core/errors/exceptions.dart';
import 'package:sentinel/core/security/credential_store.dart';
import 'package:sentinel/core/storage/app_database.dart';
import 'package:sentinel/src/hosts/data/model/host_model.dart';
import 'package:sqflite/sqflite.dart';

abstract class HostLocalDatasrc {
  const HostLocalDatasrc();

  Future<List<HostModel>> getHosts();
  Future<int> addHost({
    required HostModel host,
    required String secret,
    String? passphrase,
  });

  Future<void> update({
    required HostModel host,
    String? secret,
    String? passphrase,
  });

  Future<void> delete(int id);
}

class HostLocalDatasrcImpl implements HostLocalDatasrc {
  const HostLocalDatasrcImpl({
    required this._database,
    required this._credentialStore,
  });

  final AppDatabase _database;
  final CredentialStore _credentialStore;

  @override
  Future<List<HostModel>> getHosts() async {
    try {
      final db = await _database.database;
      final rows = await db.query(
        'hosts',
        orderBy: 'hostname COLLATE NOCASE ASC',
      );
      return rows.map(HostModel.fromMap).toList();
    } catch (e, s) {
      debugPrint(e.toString());
      debugPrintStack(stackTrace: s);
      throw const CacheException(message: 'there was an error ');
    }
  }

  @override
  Future<int> addHost({
    required HostModel host,
    required String secret,
    String? passphrase,
  }) async {
    final db = await _database.database;
    final id = await db.insert(
      'hosts',
      host.toMap()..remove('id'),
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
    try {
      await _credentialStore.save(
        hostId: id,
        secret: secret,
        passphrase: passphrase,
      );
      return id;
    } catch (e, s) {
      debugPrint(e.toString());
      debugPrintStack(stackTrace: s);
      await db.delete('hosts', where: 'id = ?', whereArgs: [id]);

      throw const CacheException(message: 'there was an error ');
    }
  }

  @override
  Future<void> update({
    required HostModel host,
    String? secret,
    String? passphrase,
  }) async {
    final id = host.id;
    if (id == null) {
      throw ArgumentError('Cannot update a host without an ID.');
    }
    final db = await _database.database;
    try {
      await db.update(
        'hosts',
        host.toMap()..remove('id'),
        where: 'id = ?',
        whereArgs: [id],
      );
      if (secret != null && secret.isNotEmpty) {
        await _credentialStore.save(
          hostId: id,
          secret: secret,
          passphrase: passphrase,
        );
      }
    } catch (e, s) {
      debugPrint(e.toString());
      debugPrintStack(stackTrace: s);
      throw const CacheException(message: 'there was an error ');
    }
  }

  @override
  Future<void> delete(int id) async {
    final db = await _database.database;
    try {
      await db.delete('hosts', where: 'id = ?', whereArgs: [id]);
      await _credentialStore.delete(id);
    } catch (e, s) {
      debugPrint(e.toString());
      debugPrintStack(stackTrace: s);
      throw const CacheException(message: 'there was an error ');
    }
  }
}
