import 'package:dartz/dartz.dart';
import 'package:sentinel/core/common/entities/host.dart';
import 'package:sentinel/core/errors/exceptions.dart';
import 'package:sentinel/core/errors/failures.dart';
import 'package:sentinel/core/utils/typedefs.dart';
import 'package:sentinel/src/hosts/data/datasrc/host_local_datasrc.dart';
import 'package:sentinel/src/hosts/data/model/host_model.dart';
import 'package:sentinel/src/hosts/domain/repositories/host_repository.dart';

class HostRepositoryImpl implements HostRepository {
  const HostRepositoryImpl(this._localDatasrc);
  final HostLocalDatasrc _localDatasrc;

  @override
  ResultFuture<List<Host>> getHosts() async {
    try {
      final hosts = await _localDatasrc.getHosts();
      return Right(hosts);
    } on CacheException catch (e) {
      return Left(CacheFailure.fromException(e));
    }
  }

  @override
  ResultFuture<int> addHost({
    required Host host,
    required String secret,
    String? passphrase,
  }) async {
    try {
      final id = await _localDatasrc.addHost(
        host: host as HostModel,
        secret: secret,
        passphrase: passphrase,
      );
      return Right(id);
    } on CacheException catch (e) {
      return Left(CacheFailure.fromException(e));
    }
  }

  @override
  ResultFuture<void> update({
    required Host host,
    String? secret,
    String? passphrase,
  }) async {
    try {
      await _localDatasrc.update(
        host: host as HostModel,
        secret: secret,
        passphrase: passphrase,
      );
      return Right(null);
    } on CacheException catch (e) {
      return Left(CacheFailure.fromException(e));
    }
  }

  @override
  ResultFuture<void> delete(int hostId) async {
    try {
      await _localDatasrc.delete(hostId);
      return Right(null);
    } on CacheException catch (e) {
      return Left(CacheFailure.fromException(e));
    }
  }
}
