import 'package:sentinel/core/common/singelton/core.dart';
import 'package:sentinel/core/extensions/string_extension.dart';
import 'package:sentinel/core/extensions/theme_mode_extension.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';

class CacheHelper {
  const CacheHelper(this._prefs);
  final SharedPreferences _prefs;

  static const _isFirstTimer = 'is_first_timer';
  static const _themeKey = 'theme_mode_key';

  Future<void> saveFirstTimer(bool isFirstTimer) async {
    await _prefs.setBool(_isFirstTimer, isFirstTimer);
  }

  Future<void> cacheThemeMode(ThemeMode themeMode) async {
    await _prefs.setString(_themeKey, themeMode.themeStringValue);
    Cache.instance.setThemeMode(themeMode);
  }

  bool isFirstTime() => _prefs.getBool(_isFirstTimer) ?? true;

  ThemeMode getThemeMode() {
    final themeModeStringValue = _prefs.getString(_themeKey);
    final themeMode =
        themeModeStringValue?.stringValueToTheme ?? ThemeMode.system;
    Cache.instance.setThemeMode(themeMode);
    return themeMode;
  }
}
