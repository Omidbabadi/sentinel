// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'active_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ActiveScreenController)
final activeScreenControllerProvider = ActiveScreenControllerProvider._();

final class ActiveScreenControllerProvider
    extends $NotifierProvider<ActiveScreenController, int> {
  ActiveScreenControllerProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'activeScreenControllerProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$activeScreenControllerHash();

  @$internal
  @override
  ActiveScreenController create() => ActiveScreenController();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(int value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<int>(value),
    );
  }
}

String _$activeScreenControllerHash() =>
    r'3314cb17dbde6bf540113911272b3a07d2e42c01';

abstract class _$ActiveScreenController extends $Notifier<int> {
  int build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<int, int>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<int, int>,
              int,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
