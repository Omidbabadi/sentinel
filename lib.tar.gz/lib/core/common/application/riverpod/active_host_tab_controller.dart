import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../entities/host.dart';

part 'active_host_tab_controller.g.dart';

typedef HostTab = ({Host host, int id});

@Riverpod(keepAlive: true)
class ActiveHostTabController extends _$ActiveHostTabController {
  @override
  List<({Host host, int id})> build() {
    return [];
  }

  void addTab(Host host) {
    final hostId = host.id;
    if (hostId == null) return;

    final index = state.indexWhere((tab) => tab.id == hostId);
    if (index == -1) {
      state = [...state, (host: host, id: hostId)];
    } else {
      state = [
        for (final tab in state)
          if (tab.id == hostId) (host: host, id: hostId) else tab,
      ];
    }
  }

  void removeTab(int hostId) {
    state = state.where((tab) => tab.id != hostId).toList();
  }

  void clear() {
    state = [];
  }
}
