// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'active_host_tab_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ActiveHostTabController)
final activeHostTabControllerProvider = ActiveHostTabControllerProvider._();

final class ActiveHostTabControllerProvider
    extends
        $NotifierProvider<
          ActiveHostTabController,
          List<({Host host, int id})>
        > {
  ActiveHostTabControllerProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'activeHostTabControllerProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$activeHostTabControllerHash();

  @$internal
  @override
  ActiveHostTabController create() => ActiveHostTabController();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(List<({Host host, int id})> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<List<({Host host, int id})>>(value),
    );
  }
}

String _$activeHostTabControllerHash() =>
    r'77e1bb80ed2b61bde40880f047deab461c228aa2';

abstract class _$ActiveHostTabController
    extends $Notifier<List<({Host host, int id})>> {
  List<({Host host, int id})> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref
            as $Ref<List<({Host host, int id})>, List<({Host host, int id})>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                List<({Host host, int id})>,
                List<({Host host, int id})>
              >,
              List<({Host host, int id})>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
