import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'active_screen_controller.g.dart';

enum ScreenTab {
  hosts,
  connections,
  settings;

  String get label => switch (this) {
    ScreenTab.hosts => 'Hosts',
    ScreenTab.connections => 'Connections',
    ScreenTab.settings => 'Settings',
  };

  String get path => switch (this) {
    ScreenTab.hosts => '/hosts',
    ScreenTab.connections => '/connections',
    ScreenTab.settings => '/settings',
  };

  static ScreenTab fromPath(String location) {
    for (final tab in ScreenTab.values) {
      if (location.startsWith(tab.path)) return tab;
    }
    return ScreenTab.hosts;
  }
}

@riverpod
class ActiveScreenController extends _$ActiveScreenController {
  @override
  int build() => 0;

  void setTab(int tab) {
    if (state != tab) state = tab;
  }
}
