import 'dart:typed_data';

import 'package:dartz/dartz.dart';
import 'package:sentinel/core/errors/failures.dart';

import '../common/entities/host.dart';

typedef DataMap = Map<String, dynamic>;

typedef ResultFuture<T> = Future<Either<Failure, T>>;

typedef HostKeyVerifier = Future<bool> Function(
  Host host,
  String keyType,
  Uint8List fingerprint,
);
