import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:sentinel/core/extensions/context_extension.dart';
import 'package:sentinel/core/services/router.dart';

import '../res/style/colors.dart';

abstract class CoreUtils {
  const CoreUtils();

  static void postFrameCallback(VoidCallback callback) {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      callback();
    });
  }

  static String? requiredValidator(String? val, String message) {
    return (val == null || val.trim().isEmpty) ? message : null;
  }

  static InputDecoration inputDecoration({
    required BuildContext context,
    required String label,
    required String hint,
    required IconData prefixIcon,
    Widget? suffixIcon,
    String? helperText,
  }) {
    final borderColor = CoreUtils.adabtiveColor(
      context,
      lightModeColour: Pallet.lightSubtleStroke,
      darkModeColur: Pallet.darkSubtleStroke,
    );
    final fillColor = CoreUtils.adabtiveColor(
      context,
      lightModeColour: Pallet.lightSurfaceLayer1,
      darkModeColur: Pallet.darkSurfaceLayer1,
    );

    return InputDecoration(
      labelText: label,
      hintText: hint,
      helperText: helperText,
      prefixIcon: Icon(prefixIcon, size: 20),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: fillColor,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: borderColor, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: borderColor, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(
          color: Pallet.operationalEmerald,
          width: 1.5,
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Pallet.criticalRose, width: 1),
      ),
    );
  }

  static Color adabtiveColor(
    BuildContext context, {
    required Color lightModeColour,
    required Color darkModeColur,
  }) {
    return context.isDarkMode ? darkModeColur : lightModeColour;
  }

  static void showSnackBar(String message, {bool isError = false}) {
    final context = rootNavigatorKey.currentContext;

    if (context == null || !context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: isError
            ? Pallet.criticalRose
            : Pallet.operationalEmerald,
        content: Text(message, style: const TextStyle(color: Colors.white)),
      ),
    );
  }

  static String? nullIfEmpty(String text) {
    final trimmed = text.trim();
    return trimmed.isEmpty ? null : trimmed;
  }
}
