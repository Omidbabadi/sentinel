import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:sentinel/core/common/entities/host.dart';
import 'package:sentinel/src/dashboard/presention/views/dashboard_screen.dart';
import 'package:sentinel/src/hosts/presention/views/connected_hosts.dart';
import 'package:sentinel/src/hosts/presention/views/edit_host_view.dart';
import 'package:sentinel/src/hosts/presention/views/hosts_view.dart';
import 'package:sentinel/src/splash_screen/presention/views/splash_screen.dart';
import 'package:sentinel/src/ssh/presention/view/terminal_view.dart';

import '../widgets/layout.dart';

part 'router.main.dart';
