import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get_it/get_it.dart';
import 'package:sentinel/core/common/application/cache_helper.dart';
import 'package:sentinel/core/security/credential_store.dart';
import 'package:sentinel/core/storage/app_database.dart';
import 'package:sentinel/src/hosts/data/datasrc/host_local_datasrc.dart';
import 'package:sentinel/src/hosts/data/repositories_impl/host_repository_impl.dart';
import 'package:sentinel/src/hosts/domain/repositories/host_repository.dart';
import 'package:sentinel/src/hosts/domain/usecases/add_host.dart';
import 'package:sentinel/src/hosts/domain/usecases/delete_host.dart';
import 'package:sentinel/src/hosts/domain/usecases/get_hosts.dart';
import 'package:sentinel/src/hosts/domain/usecases/update_host.dart';
import 'package:sentinel/src/ssh/data/datasrc/ssh_datasrc.dart';
import 'package:sentinel/src/ssh/data/repositories/ssh_repository_impl.dart';
import 'package:sentinel/src/ssh/domain/repositories/ssh_repository.dart';
import 'package:sentinel/src/ssh/domain/usecase/connect.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../handler/host_key_prompts_handler.dart';

part 'injection_container.main.dart';
