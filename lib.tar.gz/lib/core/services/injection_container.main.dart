part of 'injection_container.dart';

final sl = GetIt.instance;
final appDatabase = AppDatabase.internal();
final secureStorage = FlutterSecureStorage();
final credentialStore = CredentialStore(secureStorage);
Future<void> init() async {
  await _cacheInit();
  await _init();
  await _sshInit();
}

Future<void> _init() async {
  sl
    ..registerLazySingleton(() => GetHosts(sl()))
    ..registerLazySingleton(() => AddHost(sl()))
    ..registerLazySingleton(() => UpdateHost(sl()))
    ..registerLazySingleton(() => DeleteHost(sl()))
    ..registerLazySingleton<HostRepository>(() => HostRepositoryImpl(sl()))
    ..registerLazySingleton<HostLocalDatasrc>(
      () => HostLocalDatasrcImpl(
        database: sl<AppDatabase>(),
        credentialStore: sl<CredentialStore>(),
      ),
    )
    ..registerLazySingleton(() => appDatabase)
    ..registerLazySingleton(() => credentialStore);
}

Future<void> _sshInit() async {
  final PromptHandler hostKeyPromptHandler = PromptsHandlerImpl();
  sl
    ..registerLazySingleton(() => Connect(sl()))
    ..registerLazySingleton<SshRepository>(() => SshRepositoryImpl(sl()))
    ..registerLazySingleton<SshDatasrc>(
      () => SshDatasrcImpl(credentialStore, sl()),
    )
    ..registerLazySingleton<PromptHandler>(() => hostKeyPromptHandler);
}

Future<void> _cacheInit() async {
  final prefs = await SharedPreferences.getInstance();

  sl
    ..registerLazySingleton(() => CacheHelper(sl()))
    ..registerLazySingleton(() => prefs);
}
