part of 'router.dart';

final rootNavigatorKey = GlobalKey<NavigatorState>();

final router = GoRouter(
  navigatorKey: rootNavigatorKey,
  debugLogDiagnostics: true,
  initialLocation: '/',
  routes: [
    ShellRoute(
      builder: (context, state, child) {
        return SentinelShellScaffold(
          currentLocation: state.uri.path,
          onNavigate: (route) => context.go(route),
          isDark: true,
          onToggleTheme: () {},
          child: child,
        );
      },
      routes: [],
    ),
  ],
);

class SentinelRoutes {
  static const String home = '/';
  static const String hosts = '/hosts';
  static const String terminal = '/terminal';
  static const String groups = '/groups';
  static const String more = '/more';

  static String hostTerminal(String name, String ip) =>
      '/terminal?host=${Uri.encodeComponent(name)}&ip=${Uri.encodeComponent(ip)}';
}

// ---------------------------------------------------------------------------
// Placeholder screens — replace with real feature views when implemented.
// ---------------------------------------------------------------------------

class _SettingsPlaceholderView extends StatelessWidget {
  static const path = '/settings';
  const _SettingsPlaceholderView();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.settings_outlined, size: 64),
          SizedBox(height: 16),
          Text('Settings — coming soon'),
        ],
      ),
    );
  }
}
