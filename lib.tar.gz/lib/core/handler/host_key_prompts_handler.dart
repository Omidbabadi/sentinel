import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:sentinel/core/common/entities/host.dart';
import 'package:sentinel/core/services/router.dart';

import '../res/style/colors.dart';

abstract class PromptHandler {
  const PromptHandler();
  Future<bool> verifyHostKeyPromptsHandler({
    required Host host,
    required String keyType,
    required Uint8List fingerprint,
    required bool isFirstConnection,

    required String presentedFingerprint,
  });

  Future<bool> confirmDeletion({required Host host});
}

class PromptsHandlerImpl implements PromptHandler {
  const PromptsHandlerImpl();

  void showSnackBar() {}

  @override
  Future<bool> verifyHostKeyPromptsHandler({
    required Host host,
    required String keyType,
    required Uint8List fingerprint,
    required bool isFirstConnection,
    required String presentedFingerprint,
  }) async {
    final context = rootNavigatorKey.currentContext;

    if (context == null) return false;

    final accepted = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(
            isFirstConnection ? 'Trust SSH server?' : 'SSH host key changed',
          ),
          content: SelectableText(
            '${isFirstConnection ? 'First connection to' : 'The identity of'} '
            '${host.hostname} (${host.ip}:${host.port})\n\n'
            'Key type: $keyType\n\n'
            'Fingerprint:\n$presentedFingerprint\n\n'
            '${isFirstConnection ? 'Only trust this key if you can verify it belongs to your server.' : 'A changed fingerprint can indicate a server rebuild or a man-in-the-middle attack. Verify it independently before accepting it.'}',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Reject'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(isFirstConnection ? 'Trust key' : 'Trust new key'),
            ),
          ],
        );
      },
    );

    return accepted ?? false;
  }

  @override
  Future<bool> confirmDeletion({required Host host}) async {
    final context = rootNavigatorKey.currentContext;
    if (context == null) return false;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete Host'),
        content: Text(
          'Are you sure you want to delete "${host.hostname}"? This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Pallet.criticalRose),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    return confirmed ?? false;
  }
}
