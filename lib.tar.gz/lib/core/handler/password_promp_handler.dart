import 'package:flutter/material.dart';
import 'package:sentinel/core/common/entities/host.dart';

import '../services/router.dart';

abstract class PasswordPrompHandler {
  Future<String?> enterPassword({
    required Host host,
    required void Function()? onCancel,
  });
}

class PasswordPrompHandlerImpl implements PasswordPrompHandler {
  @override
  Future<String?> enterPassword({
    required Host host,
    required void Function()? onCancel,
  }) async {
    final context = rootNavigatorKey.currentContext;
    if (context == null) return null;
    final password = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(
            'No Password Has Been Found For This Host!\n Or Password Changed From Last Connection',
          ),
          content: SelectableText("Pleas Enter ${host.ip}'s Password"),
          actions: [
            TextButton(onPressed: () => onCancel, child: const Text('Cancel')),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text('Connect'),
            ),
          ],
        );
      },
    );
    return password;
  }
}
