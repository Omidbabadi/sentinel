import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

class AppDatabase {
  AppDatabase.internal();

  static final AppDatabase instance = AppDatabase.internal();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final databasesPath = await getDatabasesPath();
    final databasePath = p.join(databasesPath, 'sentinel.db');
    _database = await openDatabase(
      databasePath,
      version: 2,

      onCreate: (db, version) async {
        await db.execute('''
                  CREATE TABLE hosts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip TEXT NOT NULL,
                    hostname TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    username TEXT NOT NULL,
                    auth_type TEXT NOT NULL,
                    group_name TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                  )
                ''');
        await db.execute('''
          CREATE INDEX idx_hosts_name ON hosts(hostname)
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        await db.execute('''
            ALTER TABLE hosts
            ADD COLUMN os_name TEXT NOT NULL DEFAULT 'unknown'
          ''');

        await db.execute('''
            ALTER TABLE hosts
            ADD COLUMN os_version TEXT NOT NULL DEFAULT ''
          ''');
      },
    );

    return _database!;
  }
}
