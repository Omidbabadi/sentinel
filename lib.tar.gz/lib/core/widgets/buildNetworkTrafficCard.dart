import 'package:flutter/material.dart';
import 'package:sentinel/core/res/style/theme_tokens.dart';

class Buildnetworktrafficcard extends StatelessWidget {
  const Buildnetworktrafficcard({
    super.key,
    required this.tokens,
    required this.isDark,
  });
  final SentinelThemeTokens tokens;
  final bool isDark;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      tokens: tokens,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      borderRadius: 18,
      child: Row(
        children: [
          // Left stats column
          Expanded(
            flex: 5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Network Traffic',
                  style: TextStyle(
                    color: tokens.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Icon(
                      Icons.arrow_upward_rounded,
                      size: 12,
                      color: tokens.greenAccent,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '12.4 MB/s',
                      style: TextStyle(
                        color: tokens.textSecondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Icon(
                      Icons.arrow_downward_rounded,
                      size: 12,
                      color: tokens.greenAccent.withOpacity(0.8),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '3.6 MB/s',
                      style: TextStyle(
                        color: tokens.textSecondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Right sparkline chart + chevron
          Expanded(
            flex: 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Icon(
                  Icons.chevron_right_rounded,
                  size: 16,
                  color: tokens.textSecondary,
                ),
                const SizedBox(height: 2),
                SizedBox(
                  height: 32,
                  width: double.infinity,
                  child: CustomPaint(
                    painter: NetworkSplineChartPainter(
                      primaryColor: tokens.greenAccent,
                      secondaryColor: widget.isDark
                          ? const Color(0xFF527D93)
                          : const Color(0xFF8AA4B3),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
