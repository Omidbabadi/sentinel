import 'package:flutter/material.dart';

import '../res/style/theme_tokens.dart';

class Buildrecenthostscard extends StatelessWidget {
  const Buildrecenthostscard({super.key, required this.tokens});
  final SentinelThemeTokens tokens;

  @override
  Widget build(BuildContext context) {
    final hosts = [
      _HostItemData(
        name: 'Ubuntu Server',
        ip: '192.168.1.100',
        status: 'Online',
        statusColor: tokens.greenAccent,
        time: '22:04',
        distro: LinuxDistro.ubuntu,
      ),
      _HostItemData(
        name: 'Arch Server',
        ip: '192.168.1.101',
        status: 'Online',
        statusColor: tokens.greenAccent,
        time: '12:36',
        distro: LinuxDistro.arch,
      ),
      _HostItemData(
        name: 'Debian Server',
        ip: '10.0.0.5',
        status: 'Staging',
        statusColor: tokens.yellowAccent,
        time: '1d ago',
        distro: LinuxDistro.debian,
      ),
      _HostItemData(
        name: 'Fedora Server',
        ip: '192.168.1.102',
        status: 'Online',
        statusColor: tokens.greenAccent,
        time: '1d ago',
        distro: LinuxDistro.fedora,
      ),
    ];

    return GlassCard(
      tokens: tokens,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      borderRadius: 20,
      child: Column(
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Recent Hosts',
                style: TextStyle(
                  color: tokens.textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Row(
                children: [
                  Text(
                    'View all',
                    style: TextStyle(
                      color: tokens.textSecondary,
                      fontSize: 11,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  const SizedBox(width: 3),
                  Icon(
                    Icons.arrow_forward_rounded,
                    size: 12,
                    color: tokens.textSecondary,
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          // List items
          for (int i = 0; i < hosts.length; i++) ...[
            _buildHostRow(hosts[i], tokens),
            if (i < hosts.length - 1)
              Divider(height: 14, thickness: 0.7, color: tokens.dividerColor),
          ],
        ],
      ),
    );
  }
}
