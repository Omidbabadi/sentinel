import 'package:flutter/material.dart';
import 'package:sentinel/core/res/style/colors.dart';

import '../utils/core_utils.dart';

class AppBarBottom extends StatelessWidget implements PreferredSizeWidget {
  const AppBarBottom({super.key});

  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize: preferredSize,
      child: ColoredBox(
        color: CoreUtils.adabtiveColor(
          context,

          lightModeColour: Pallet.darkBackground,
          darkModeColur: Colors.white,
        ),
        child: const SizedBox(width: double.infinity, height: 1),
      ),
    );
  }

  @override
  Size get preferredSize => Size.zero;
}
