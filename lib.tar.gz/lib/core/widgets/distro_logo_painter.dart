import 'dart:math' as math;

import 'package:flutter/material.dart';

class DistroLogoPainter extends CustomPainter {
  final LinuxDistro distro;

  DistroLogoPainter({required this.distro});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    switch (distro) {
      case LinuxDistro.ubuntu:
        // Ubuntu Orange Circle
        canvas.drawCircle(
          center,
          radius,
          Paint()..color = const Color(0xFFE95420),
        );
        // Circle of Friends ring + 3 nodes
        final ringRadius = radius * 0.46;
        canvas.drawCircle(
          center,
          ringRadius,
          Paint()
            ..color = Colors.white
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2.0,
        );
        for (int i = 0; i < 3; i++) {
          final angle = (i * 120 - 30) * math.pi / 180;
          final nodeCenter = Offset(
            center.dx + (ringRadius + 2.2) * math.cos(angle),
            center.dy + (ringRadius + 2.2) * math.sin(angle),
          );
          canvas.drawCircle(
            nodeCenter,
            3.3,
            Paint()..color = const Color(0xFFE95420),
          );
          canvas.drawCircle(nodeCenter, 2.1, Paint()..color = Colors.white);
        }
        break;

      case LinuxDistro.arch:
        // Arch Blue Circle
        canvas.drawCircle(
          center,
          radius,
          Paint()..color = const Color(0xFF1793D1),
        );
        // Arch A-peak silhouette
        final path = Path()
          ..moveTo(center.dx, center.dy - radius * 0.58)
          ..lineTo(center.dx - radius * 0.48, center.dy + radius * 0.48)
          ..quadraticBezierTo(
            center.dx - radius * 0.18,
            center.dy + radius * 0.32,
            center.dx - radius * 0.12,
            center.dy + radius * 0.30,
          )
          ..arcToPoint(
            Offset(center.dx + radius * 0.12, center.dy + radius * 0.30),
            radius: Radius.circular(radius * 0.16),
            clockwise: true,
          )
          ..quadraticBezierTo(
            center.dx + radius * 0.18,
            center.dy + radius * 0.32,
            center.dx + radius * 0.48,
            center.dy + radius * 0.48,
          )
          ..close();
        canvas.drawPath(path, Paint()..color = Colors.white);
        break;

      case LinuxDistro.debian:
        // Debian Crimson Circle
        canvas.drawCircle(
          center,
          radius,
          Paint()..color = const Color(0xFFD70A53),
        );
        // Spiral swirl
        final swirlPaint = Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.0
          ..strokeCap = StrokeCap.round;
        final swirlPath = Path();
        for (double t = 0; t < 3.6 * math.pi; t += 0.15) {
          final r = (t / (3.6 * math.pi)) * radius * 0.56;
          final x = center.dx + r * math.cos(t + 0.8);
          final y = center.dy + r * math.sin(t + 0.8);
          if (t == 0) {
            swirlPath.moveTo(x, y);
          } else {
            swirlPath.lineTo(x, y);
          }
        }
        canvas.drawPath(swirlPath, swirlPaint);
        break;

      case LinuxDistro.fedora:
        // Fedora Navy Blue Circle
        canvas.drawCircle(
          center,
          radius,
          Paint()..color = const Color(0xFF294172),
        );
        // Stylized 'f'
        final fPaint = Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..strokeCap = StrokeCap.round;
        final fPath = Path()
          ..moveTo(center.dx + radius * 0.25, center.dy - radius * 0.38)
          ..cubicTo(
            center.dx - radius * 0.1,
            center.dy - radius * 0.48,
            center.dx - radius * 0.08,
            center.dy + radius * 0.48,
            center.dx - radius * 0.32,
            center.dy + radius * 0.42,
          )
          ..moveTo(center.dx - radius * 0.28, center.dy + 0.5)
          ..lineTo(center.dx + radius * 0.22, center.dy + 0.5);
        canvas.drawPath(fPath, fPaint);
        break;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

enum LinuxDistro { ubuntu, arch, debian, fedora }
