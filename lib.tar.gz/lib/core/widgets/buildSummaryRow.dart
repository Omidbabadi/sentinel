import 'package:flutter/material.dart';

import '../res/style/theme_tokens.dart';

class BuildSummaryRow extends StatelessWidget {
  const BuildSummaryRow({super.key, required this.tokens});
  final SentinelThemeTokens tokens;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            tokens: tokens,
            count: '6',
            label: 'Total Hosts',
            accentColor: tokens.blueAccent,
            dotIndicatorColor: tokens.greenAccent,
            iconWidget: _buildServerStackBadge(tokens.blueAccent),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            tokens: tokens,
            count: '5',
            label: 'Online',
            accentColor: tokens.greenAccent,
            iconWidget: _buildGlowingOrbBadge(tokens.greenAccent),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            tokens: tokens,
            count: '1',
            label: 'Offline',
            accentColor: tokens.redAccent,
            iconWidget: _buildGlowingOrbBadge(tokens.redAccent),
          ),
        ),
      ],
    );
  }
}

Widget _buildSummaryRow(SentinelThemeTokens tokens) {}
