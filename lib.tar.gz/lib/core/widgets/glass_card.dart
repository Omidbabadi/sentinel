import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

import '../res/style/theme_tokens.dart';

class GlassCard extends StatelessWidget {
  final SentinelThemeTokens tokens;
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double borderRadius;

  const GlassCard({
    super.key,
    required this.tokens,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.borderRadius = 18,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: tokens.cardSurface,
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(color: tokens.cardBorder, width: 0.9),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(
                  alpha: tokens.isDark ? 0.22 : 0.04,
                ),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class GlassOrbPainter extends CustomPainter {
  final bool isDark;

  GlassOrbPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.5, size.height * 0.5);
    final radius = size.width * 0.44;
    final rect = Rect.fromCircle(center: center, radius: radius);

    // Soft outer shadow
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(isDark ? 0.45 : 0.12)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22);
    canvas.drawCircle(center.translate(-6, 14), radius * 0.92, shadowPaint);

    // Base sphere body gradient
    final bodyPaint = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.35, -0.45),
        radius: 1.1,
        colors: isDark
            ? [
                const Color(0xFF565B66).withValues(alpha: 0.85),
                const Color(0xFF22262E).withValues(alpha: 0.92),
                const Color(0xFF0E1014).withValues(alpha: 0.96),
                const Color(0xFF393E47).withValues(alpha: 0.85),
              ]
            : [
                const Color(0xFFFFFFFF).withValues(alpha: 0.95),
                const Color(0xFFE3E0D8).withValues(alpha: 0.75),
                const Color(0xFFC5C0B4).withValues(alpha: 0.65),
                const Color(0xFFF7F5F0).withValues(alpha: 0.9),
              ],
        stops: const [0.0, 0.45, 0.82, 1.0],
      ).createShader(rect);
    canvas.drawCircle(center, radius, bodyPaint);

    // Internal caustic / glass refraction bands
    canvas.save();
    canvas.clipPath(Path()..addOval(rect));

    final refractionPath = Path()
      ..moveTo(center.dx - radius, center.dy + radius * 0.2)
      ..quadraticBezierTo(
        center.dx - radius * 0.2,
        center.dy - radius * 0.7,
        center.dx + radius * 0.8,
        center.dy - radius * 0.2,
      )
      ..quadraticBezierTo(
        center.dx + radius * 0.2,
        center.dy + radius * 0.6,
        center.dx - radius,
        center.dy + radius * 0.2,
      );

    final refractionPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withValues(alpha: isDark ? 0.18 : 0.55),
          Colors.transparent,
        ],
      ).createShader(rect)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawPath(refractionPath, refractionPaint);

    // Top-left bright specular reflection
    final highlightCenter = center.translate(-radius * 0.35, -radius * 0.35);
    final highlightPaint = Paint()
      ..shader =
          RadialGradient(
            colors: [
              Colors.white.withValues(alpha: isDark ? 0.55 : 0.9),
              Colors.white.withValues(alpha: 0.0),
            ],
          ).createShader(
            Rect.fromCircle(center: highlightCenter, radius: radius * 0.45),
          );
    canvas.drawCircle(highlightCenter, radius * 0.45, highlightPaint);

    canvas.restore();

    // Crisp rim highlight
    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..shader = SweepGradient(
        colors: [
          Colors.white.withValues(alpha: isDark ? 0.45 : 0.85),
          Colors.white.withValues(alpha: 0.05),
          Colors.white.withValues(alpha: isDark ? 0.25 : 0.6),
          Colors.white.withValues(alpha: 0.05),
          Colors.white.withValues(alpha: isDark ? 0.45 : 0.85),
        ],
      ).createShader(rect);
    canvas.drawCircle(center, radius, rimPaint);
  }

  @override
  bool shouldRepaint(covariant GlassOrbPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}

class SentinelCubeLogoPainter extends CustomPainter {
  final bool isDark;

  SentinelCubeLogoPainter({required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r = size.width * 0.48;

    Offset hexPoint(int i, double radius) {
      final angle = (i * 60 - 90) * math.pi / 180;
      return Offset(
        cx + radius * math.cos(angle),
        cy + radius * math.sin(angle),
      );
    }

    // Outer Hexagon
    final outerPath = Path();
    for (int i = 0; i < 6; i++) {
      final pt = hexPoint(i, r);
      if (i == 0) {
        outerPath.moveTo(pt.dx, pt.dy);
      } else {
        outerPath.lineTo(pt.dx, pt.dy);
      }
    }
    outerPath.close();

    canvas.drawPath(
      outerPath,
      Paint()
        ..color = isDark ? const Color(0xFF3A3F47) : const Color(0xFF2C2A29),
    );

    // Left facet highlight
    final leftFace = Path()
      ..moveTo(cx, cy)
      ..lineTo(hexPoint(4, r).dx, hexPoint(4, r).dy)
      ..lineTo(hexPoint(5, r).dx, hexPoint(5, r).dy)
      ..lineTo(hexPoint(0, r).dx, hexPoint(0, r).dy)
      ..close();
    canvas.drawPath(
      leftFace,
      Paint()
        ..color = isDark ? const Color(0xFFD5D9E0) : const Color(0xFF8C857B),
    );

    // Inner Isometric Cube cutout
    final ir = r * 0.52;
    final innerTop = Path()
      ..moveTo(cx, cy)
      ..lineTo(hexPoint(5, ir).dx, hexPoint(5, ir).dy)
      ..lineTo(hexPoint(0, ir).dx, hexPoint(0, ir).dy)
      ..lineTo(hexPoint(1, ir).dx, hexPoint(1, ir).dy)
      ..close();
    canvas.drawPath(innerTop, Paint()..color = Colors.white);

    final innerRight = Path()
      ..moveTo(cx, cy)
      ..lineTo(hexPoint(1, ir).dx, hexPoint(1, ir).dy)
      ..lineTo(hexPoint(2, ir).dx, hexPoint(2, ir).dy)
      ..lineTo(hexPoint(3, ir).dx, hexPoint(3, ir).dy)
      ..close();
    canvas.drawPath(
      innerRight,
      Paint()
        ..color = isDark ? const Color(0xFF9EA4B0) : const Color(0xFFD6D1C7),
    );
  }

  @override
  bool shouldRepaint(covariant SentinelCubeLogoPainter oldDelegate) =>
      oldDelegate.isDark != isDark;
}
