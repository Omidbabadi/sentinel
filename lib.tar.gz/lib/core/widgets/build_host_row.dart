import 'package:flutter/material.dart';
import 'package:sentinel/core/res/style/theme_tokens.dart';

import '../common/entities/host.dart';

class BuildHostRow extends StatelessWidget {
  const BuildHostRow({
    super.key,
    required this.host,
    required this.tokens,
    required this.isDark,
  });
  final Host host;
  final SentinelThemeTokens tokens;
  final bool isDark;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.5),
      child: Row(
        children: [
          // Distro Circle Logo
          SizedBox(
            width: 32,
            height: 32,
            child: CustomPaint(painter: DistroLogoPainter(distro: host.distro)),
          ),
          const SizedBox(width: 10),
          // Name & IP
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  host.hostname,
                  style: TextStyle(
                    color: tokens.textPrimary,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 1.5),
                Text(
                  host.ip,
                  style: TextStyle(color: tokens.textSecondary, fontSize: 10.5),
                ),
              ],
            ),
          ),
          // Status Badge Pill
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
            decoration: BoxDecoration(
              color: host.statusColor.withOpacity(widget.isDark ? 0.16 : 0.14),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: host.statusColor.withOpacity(0.28),
                width: 0.7,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 5,
                  height: 5,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: host.statusColor,
                  ),
                ),
                const SizedBox(width: 5),
                Text(
                  host.status,
                  style: TextStyle(
                    color: isDark
                        ? host.statusColor
                        : Color.lerp(host.statusColor, Colors.black, 0.25),
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          // Timestamp
          SizedBox(
            width: 36,
            child: Text(
              host.time,
              textAlign: TextAlign.right,
              style: TextStyle(color: tokens.textSecondary, fontSize: 10.5),
            ),
          ),
          const SizedBox(width: 6),
          Icon(
            Icons.chevron_right_rounded,
            size: 15,
            color: tokens.textSecondary.withOpacity(0.7),
          ),
        ],
      ),
    );
  }
}
