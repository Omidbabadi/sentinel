import 'package:flutter/material.dart';
import 'package:sentinel/core/res/style/colors.dart';
import 'package:sentinel/core/res/style/text.dart';

class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.style});
  final TextStyle? style;
  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        text: 'Senti',
        style: style ?? TextStyles.appLogo,
        children: [
          TextSpan(
            text: 'nel',
            style: TextStyle(color: Pallet.classicAdabtiveTextColor(context)),
          ),
        ],
      ),
    );
  }
}
