import 'package:flutter/material.dart';

import '../res/style/theme_tokens.dart';

class BuildGreetingSection extends StatelessWidget {
  const BuildGreetingSection({
    super.key,
    required this.isDark,
    required this.tokens,
  });
  final bool isDark;
  final SentinelThemeTokens tokens;

  @override
  Widget build(BuildContext context) {
    final greeting = isDark ? 'Good evening,' : 'Good morning,';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$greeting\nOmid',
          style: TextStyle(
            color: tokens.textPrimary,
            fontSize: 27,
            height: 1.15,
            fontWeight: FontWeight.w400,
            letterSpacing: -0.6,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Your servers are running smoothly.',
          style: TextStyle(
            color: tokens.textSecondary,
            fontSize: 12.5,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}
