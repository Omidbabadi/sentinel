abstract class Media {
  const Media();

  static const connectionsIcon = '/assets/icons/graph-star.svg';
}
