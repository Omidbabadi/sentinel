import 'package:flutter/material.dart';

class SentinelThemeTokens {
  final bool isDark;

  SentinelThemeTokens(this.isDark);

  Color get bgTop => isDark ? const Color(0xFF15181E) : const Color(0xFFF3F1EC);
  Color get bgBottom =>
      isDark ? const Color(0xFF0E1014) : const Color(0xFFE7E4DD);

  Color get textPrimary =>
      isDark ? const Color(0xFFF7F8FA) : const Color(0xFF1C1E21);
  Color get textSecondary =>
      isDark ? const Color(0xFF9399A6) : const Color(0xFF72767D);
  Color get textMuted =>
      isDark ? const Color(0xFF6B717E) : const Color(0xFF9599A1);

  Color get cardSurface => isDark
      ? const Color(0xFF232830).withValues(alpha: 0.58)
      : const Color(0xFFFFFFFF).withValues(alpha: 0.54);

  Color get cardBorder => isDark
      ? Colors.white.withValues(alpha: 0.11)
      : Colors.white.withValues(alpha: 0.75);

  Color get innerPillSurface => isDark
      ? const Color(0xFF2B303A).withValues(alpha: 0.65)
      : const Color(0xFFF4F3EF).withValues(alpha: 0.72);

  Color get innerPillBorder => isDark
      ? Colors.white.withValues(alpha: 0.08)
      : Colors.black.withValues(alpha: 0.05);

  Color get dividerColor => isDark
      ? Colors.white.withValues(alpha: 0.06)
      : Colors.black.withValues(alpha: 0.05);

  Color get greenAccent => const Color(0xFF39C98A);
  Color get redAccent => const Color(0xFFF05454);
  Color get yellowAccent => const Color(0xFFE9A93B);
  Color get blueAccent => const Color(0xFF4796E5);
}
