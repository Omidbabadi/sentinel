import 'dart:ui';

import 'package:flutter/material.dart';

import 'core/res/style/theme_tokens.dart';
import 'core/services/router.dart';
import 'core/widgets/glass_orb_painter.dart';

/// Drop-in `ShellRoute` builder widget for `go_router`.
/// Pass `state.uri.path` to `currentLocation` and `(route) => context.go(route)`
/// to `onNavigate`.
class SentinelShellScaffold extends StatelessWidget {
  final String currentLocation;
  final ValueChanged<String> onNavigate;
  final bool isDark;
  final Widget child;

  const SentinelShellScaffold({
    super.key,
    required this.currentLocation,
    required this.onNavigate,
    required this.isDark,
    required this.child,
  });

  int _locationToIndex(String path) {
    if (path.startsWith(SentinelRoutes.hosts)) return 1;
    if (path.startsWith(SentinelRoutes.terminal)) return 2;
    if (path.startsWith(SentinelRoutes.groups)) return 3;
    if (path.startsWith(SentinelRoutes.more)) return 4;
    return 0;
  }

  String _indexToLocation(int index) {
    switch (index) {
      case 0:
        return SentinelRoutes.home;
      case 1:
        return SentinelRoutes.hosts;
      case 2:
        return SentinelRoutes.terminal;
      case 3:
        return SentinelRoutes.groups;
      case 4:
        return SentinelRoutes.more;
      default:
        return SentinelRoutes.home;
    }
  }

  @override
  Widget build(BuildContext context) {
    final tokens = SentinelThemeTokens(isDark);
    final selectedIndex = _locationToIndex(currentLocation);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [tokens.bgTop, tokens.bgBottom],
        ),
      ),
      child: Stack(
        children: [
          // Ambient subtle glow behind the 3D sphere and cards
          Positioned(
            top: 90,
            right: -35,
            child: IgnorePointer(
              child: CustomPaint(
                size: const Size(210, 210),
                painter: GlassOrbPainter(isDark: isDark),
              ),
            ),
          ),

          // Ambient teal/blue subtle radial glow behind Network Traffic card
          if (isDark)
            Positioned(
              top: 300,
              left: 70,
              child: IgnorePointer(
                child: Container(
                  width: 180,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF32789A).withValues(alpha: 0.18),
                        blurRadius: 65,
                        spreadRadius: 25,
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // Active GoRoute Child View
          Positioned.fill(child: child),

          // Bottom Floating Glassmorphic Dock + Center Terminal Orb
          Positioned(
            left: 16,
            right: 16,
            bottom: 16,
            child: _buildBottomNavigation(tokens, selectedIndex),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigation(
    SentinelThemeTokens tokens,
    int selectedNavIndex,
  ) {
    final isTerminalSelected = selectedNavIndex == 2;

    return SizedBox(
      height: 66,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.bottomCenter,
        children: [
          // Frosted Pill Bar
          ClipRRect(
            borderRadius: BorderRadius.circular(32),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                height: 56,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: isDark
                      ? const Color(0xFF1A1E24).withValues(alpha: 0.82)
                      : Colors.white.withValues(alpha: 0.75),
                  borderRadius: BorderRadius.circular(32),
                  border: Border.all(color: tokens.cardBorder, width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(
                        alpha: isDark ? 0.4 : 0.08,
                      ),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNavItem(
                      index: 0,
                      selectedNavIndex: selectedNavIndex,
                      icon: Icons.home_filled,
                      label: 'Home',
                      tokens: tokens,
                    ),
                    _buildNavItem(
                      index: 1,
                      selectedNavIndex: selectedNavIndex,
                      icon: Icons.dns_outlined,
                      label: 'Hosts',
                      tokens: tokens,
                    ),
                    const SizedBox(width: 54), // Space for center orb
                    _buildNavItem(
                      index: 3,
                      selectedNavIndex: selectedNavIndex,
                      icon: Icons.people_outline_rounded,
                      label: 'Groups',
                      tokens: tokens,
                    ),
                    _buildNavItem(
                      index: 4,
                      selectedNavIndex: selectedNavIndex,
                      icon: Icons.more_horiz_rounded,
                      label: 'More',
                      tokens: tokens,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Raised Center Glowing Terminal Button
          Positioned(
            top: 0,
            child: GestureDetector(
              onTap: () => onNavigate(_indexToLocation(2)),
              child: Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    center: const Alignment(-0.3, -0.4),
                    radius: 0.9,
                    colors: isDark
                        ? [
                            const Color(0xFF3A4352),
                            const Color(0xFF1F242D),
                            const Color(0xFF15181F),
                          ]
                        : [
                            const Color(0xFFFFFFFF),
                            const Color(0xFFE0DDD5),
                            const Color(0xFFCCC8BE),
                          ],
                  ),
                  border: Border.all(
                    color: isTerminalSelected
                        ? tokens.greenAccent
                        : (isDark
                              ? const Color(0xFF7096B8).withValues(alpha: 0.55)
                              : Colors.white.withValues(alpha: 0.9)),
                    width: 1.4,
                  ),
                  boxShadow: [
                    if (isDark)
                      BoxShadow(
                        color:
                            (isTerminalSelected
                                    ? tokens.greenAccent
                                    : const Color(0xFF4788C7))
                                .withValues(alpha: 0.28),
                        blurRadius: 16,
                        spreadRadius: 1,
                      ),
                    BoxShadow(
                      color: Colors.black.withValues(
                        alpha: isDark ? 0.5 : 0.15,
                      ),
                      blurRadius: 12,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    '>_',
                    style: TextStyle(
                      color: isTerminalSelected
                          ? tokens.greenAccent
                          : tokens.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.5,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required int selectedNavIndex,
    required IconData icon,
    required String label,
    required SentinelThemeTokens tokens,
  }) {
    final isSelected = selectedNavIndex == index;
    final color = isSelected ? tokens.textPrimary : tokens.textSecondary;

    return GestureDetector(
      onTap: () => onNavigate(_indexToLocation(index)),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 52,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 19, color: color),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 9.5,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
